<template>
  <div>  ddddddd</div>
</template>

<script>
//  import axios from 'axios';
// const axios = require('axios');
export default {
  name: 'name',
  data: function() {	
    return {}
  },
  created:function(){
    this.gettoken();
  },
  methods: {
    gettoken:function(){
     
      //   axios.post('http://192.168.10.81:9191/api/AA/GetAA',{},{
      //   headers:{
      //     authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJOYW1lIjoic3RyaW5nIiwiVXNlciI6InN0cmluZyIsIm5iZiI6MTY2MTIyMjA0NiwiZXhwIjoxNjYyMDg2MDQ2LCJpc3MiOiIyMjIyIiwiYXVkIjoiMzMzMyJ9.X5pYZQNmAUuivjnBgATze6lnYNtZm3QEmd4m3eNspEE`,
      //   }
      // }).then(function(json){
      //   console.log(json);
      // })

    this.axios.get('http://60.2.176.226:10103/api/Device', {
    firstName: 'Fred',
    lastName: 'Flintstone'
  })
  .then(function (response) {
    console.log(response);
  })
  .catch(function (error) {
    console.log(error);
  });
      
      //  this.axios.get('http://192.168.10.81:9191/api/AA/GetBB').then(function(json){
      //    console.log(json);
      //  })
    }
  }
}
</script>

<style scoped>

</style>